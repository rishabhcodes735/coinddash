import { describe, expect, it } from "vitest";

const apiBaseUrl = process.env.VITE_COINGECKO_API_URL || "https://api.coingecko.com/api/v3";

describe("CoinGecko environment configuration", () => {
  it("reaches the lightweight ping endpoint", async () => {
    const response = await fetch(`${apiBaseUrl.replace(/\/$/, "")}/ping`);
    expect(response.ok).toBe(true);

    const payload = (await response.json()) as { gecko_says?: string };
    expect(payload.gecko_says).toBeDefined();
  }, 15000);
});
