import { useEffect, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  Bookmark,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  Compass,
  Copy,
  Flame,
  LayoutDashboard,
  LineChart,
  Loader2,
  Menu,
  RefreshCw,
  Search,
  Settings2,
  Sparkles,
  Star,
  TrendingUp,
  Wallet,
  X,
  Zap,
} from "lucide-react";
import "./index.css";

type Coin = {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  price_change_percentage_24h: number;
  total_volume: number;
  sparkline_in_7d?: { price: number[] };
};

type Panel = "overview" | "trending" | "watchlist";

const COINGECKO_API_URL = (import.meta.env.VITE_COINGECKO_API_URL || "https://api.coingecko.com/api/v3").replace(/\/$/, "");
const API_URL = `${COINGECKO_API_URL}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=40&page=1&sparkline=true&price_change_percentage=24h`;

const fallbackCoins: Coin[] = [
  {
    id: "bitcoin",
    symbol: "btc",
    name: "Bitcoin",
    image: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png",
    current_price: 104238.42,
    market_cap: 2070000000000,
    market_cap_rank: 1,
    price_change_percentage_24h: 2.84,
    total_volume: 38200000000,
    sparkline_in_7d: { price: [3, 4, 3.6, 5.2, 5.6, 6.7, 6.2, 7.8, 8.7, 8.3, 9.5, 10] },
  },
  {
    id: "ethereum",
    symbol: "eth",
    name: "Ethereum",
    image: "https://assets.coingecko.com/coins/images/279/large/ethereum.png",
    current_price: 3812.16,
    market_cap: 459000000000,
    market_cap_rank: 2,
    price_change_percentage_24h: 1.48,
    total_volume: 16400000000,
    sparkline_in_7d: { price: [5, 5.8, 5.2, 6.8, 6.4, 7.5, 8.4, 7.9, 8.8, 9.3, 9.1, 10] },
  },
  {
    id: "solana",
    symbol: "sol",
    name: "Solana",
    image: "https://assets.coingecko.com/coins/images/4128/large/solana.png",
    current_price: 187.64,
    market_cap: 90300000000,
    market_cap_rank: 5,
    price_change_percentage_24h: 6.72,
    total_volume: 4210000000,
    sparkline_in_7d: { price: [3, 3.4, 3.2, 4.2, 4.1, 5.1, 5.8, 5.1, 6.4, 7.2, 8.7, 10] },
  },
  {
    id: "binancecoin",
    symbol: "bnb",
    name: "BNB",
    image: "https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png",
    current_price: 684.91,
    market_cap: 102000000000,
    market_cap_rank: 4,
    price_change_percentage_24h: -0.82,
    total_volume: 1100000000,
    sparkline_in_7d: { price: [9, 8.5, 8.8, 8.2, 7.8, 8.4, 8, 8.2, 7.6, 7.9, 7.3, 7] },
  },
  {
    id: "ripple",
    symbol: "xrp",
    name: "XRP",
    image: "https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png",
    current_price: 2.34,
    market_cap: 135000000000,
    market_cap_rank: 3,
    price_change_percentage_24h: 4.11,
    total_volume: 2830000000,
    sparkline_in_7d: { price: [3, 4, 3.4, 4.1, 5.2, 4.8, 5.7, 6.1, 7, 7.8, 8.6, 10] },
  },
  {
    id: "dogecoin",
    symbol: "doge",
    name: "Dogecoin",
    image: "https://assets.coingecko.com/coins/images/5/large/dogecoin.png",
    current_price: 0.192,
    market_cap: 28500000000,
    market_cap_rank: 8,
    price_change_percentage_24h: 9.31,
    total_volume: 1790000000,
    sparkline_in_7d: { price: [2.1, 2.8, 2.6, 3.5, 3.9, 3.4, 4.7, 5.4, 6.5, 7.1, 8.7, 10] },
  },
];

const panelMeta: Record<Panel, { label: string; eyebrow: string; title: string; description: string }> = {
  overview: {
    label: "Market Overview",
    eyebrow: "THE BIG PICTURE",
    title: "Markets, without the noise.",
    description: "A calmer way to track the assets moving the market right now.",
  },
  trending: {
    label: "Trending",
    eyebrow: "MOMENTUM RADAR",
    title: "What’s catching fire.",
    description: "The coins with the strongest 24-hour momentum across the market.",
  },
  watchlist: {
    label: "Watchlist",
    eyebrow: "YOUR SIGNALS",
    title: "Keep your eyes here.",
    description: "Pin the coins worth a closer look and build your own signal board.",
  },
};

function formatCurrency(value: number, compact = false) {
  if (compact) {
    return new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 2 }).format(value);
  }
  if (value < 1) return `$${value.toFixed(4)}`;
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: value > 100 ? 0 : 2 }).format(value);
}

function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function LogoMark({ small = false }: { small?: boolean }) {
  return (
    <div className={`logo-mark ${small ? "logo-mark--small" : ""}`} aria-hidden="true">
      <span />
      <span />
      <span />
    </div>
  );
}

function Sparkline({ coin, muted = false }: { coin: Coin; muted?: boolean }) {
  const values = coin.sparkline_in_7d?.price?.slice(-16) || [3, 4, 3.4, 5, 4.5, 6, 7, 6, 7.8, 8.4, 8.1, 9.6];
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const points = values.map((value, index) => `${(index / (values.length - 1)) * 100},${31 - ((value - min) / range) * 25}`).join(" ");
  const positive = coin.price_change_percentage_24h >= 0;
  return (
    <svg viewBox="0 0 100 34" className={`sparkline ${muted ? "sparkline--muted" : ""}`} preserveAspectRatio="none" aria-label={`${coin.name} seven day chart`}>
      <defs>
        <linearGradient id={`fill-${coin.id}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={positive ? "#b6ff45" : "#ff6b96"} stopOpacity=".23" />
          <stop offset="100%" stopColor={positive ? "#b6ff45" : "#ff6b96"} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,34 ${points} 100,34`} fill={`url(#fill-${coin.id})`} />
      <polyline points={points} fill="none" stroke={positive ? "#b6ff45" : "#ff6b96"} strokeWidth="1.7" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function CoinAvatar({ coin, index }: { coin: Coin; index?: number }) {
  const colors = ["#ffb81c", "#8b8fff", "#a5f23f", "#f4a6ff", "#ff7f6e", "#76e8ff"];
  return (
    <div className="coin-avatar" style={{ background: `${colors[(index || coin.market_cap_rank) % colors.length]}18`, color: colors[(index || coin.market_cap_rank) % colors.length] }}>
      <img src={coin.image} alt="" onError={(event) => { event.currentTarget.style.display = "none"; }} />
      <span>{coin.symbol.slice(0, 1).toUpperCase()}</span>
    </div>
  );
}

function Sidebar({ activePanel, onChange, mobileOpen, onClose }: { activePanel: Panel; onChange: (panel: Panel) => void; mobileOpen: boolean; onClose: () => void }) {
  const navItems: { id: Panel; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "overview", label: "Market Overview", icon: LayoutDashboard },
    { id: "trending", label: "Trending", icon: Flame },
    { id: "watchlist", label: "Watchlist", icon: Bookmark },
  ];
  return (
    <>
      <aside className={`sidebar ${mobileOpen ? "sidebar--open" : ""}`}>
        <div className="sidebar-top">
          <div className="brand-lockup">
            <LogoMark />
            <div><div className="brand-name">Coin<span>Dash</span></div><div className="brand-sub">Live market intelligence</div></div>
          </div>
          <button className="mobile-close" onClick={onClose} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="workspace-pill"><span className="workspace-dot" /> Club workspace <ChevronRight size={14} /></div>
        <nav className="side-nav" aria-label="Main navigation">
          <div className="nav-kicker">Workspace</div>
          {navItems.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`side-nav-item ${activePanel === id ? "side-nav-item--active" : ""}`} onClick={() => { onChange(id); onClose(); }}>
              <Icon size={17} strokeWidth={1.8} /><span>{label}</span>{id === "watchlist" && <span className="nav-count">4</span>}
            </button>
          ))}
          <div className="nav-kicker nav-kicker--spaced">Tools</div>
          <button className="side-nav-item" onClick={() => onChange("overview")}><Compass size={17} strokeWidth={1.8} /><span>Discover</span><span className="nav-soon">soon</span></button>
          <button className="side-nav-item" onClick={() => onChange("overview")}><Settings2 size={17} strokeWidth={1.8} /><span>Preferences</span></button>
        </nav>
        <div className="sidebar-bottom">
          <div className="signal-card">
            <div className="signal-icon"><Sparkles size={15} /></div>
            <div><div className="signal-title">Club signal</div><div className="signal-copy">Learn together. Trade smarter.</div></div>
          </div>
          <div className="profile-row"><div className="profile-avatar">JD</div><div className="profile-copy"><strong>Jordan Davis</strong><span>Member since 2024</span></div><MoreDots /></div>
        </div>
      </aside>
      {mobileOpen && <button className="sidebar-overlay" onClick={onClose} aria-label="Close menu" />}
    </>
  );
}

function MoreDots() { return <span className="more-dots"><i /><i /><i /></span>; }

function StatCard({ label, value, change, tone = "lime", icon }: { label: string; value: string; change?: string; tone?: "lime" | "purple" | "white"; icon: React.ReactNode }) {
  return <div className={`stat-card stat-card--${tone}`}><div className="stat-top"><span>{label}</span><span className="stat-icon">{icon}</span></div><div className="stat-value">{value}</div>{change && <div className="stat-change"><ArrowUpRight size={14} /> {change} <span>today</span></div>}</div>;
}

function MarketCard({ coin, index, watchlisted, onToggle }: { coin: Coin; index: number; watchlisted: boolean; onToggle: () => void }) {
  const positive = coin.price_change_percentage_24h >= 0;
  return (
    <article className="market-card hover-lift">
      <div className="market-card-head"><div className="coin-ident"><CoinAvatar coin={coin} index={index} /><div><div className="coin-name">{coin.name}</div><div className="coin-symbol">{coin.symbol.toUpperCase()} <span>#{coin.market_cap_rank}</span></div></div></div><button className={`watch-button ${watchlisted ? "watch-button--active" : ""}`} onClick={onToggle} aria-label={`${watchlisted ? "Remove" : "Add"} ${coin.name} ${watchlisted ? "from" : "to"} watchlist`}><Star size={16} fill={watchlisted ? "currentColor" : "none"} /></button></div>
      <div className="market-card-mid"><div><div className="coin-price">{formatCurrency(coin.current_price)}</div><div className={`coin-change ${positive ? "is-positive" : "is-negative"}`}>{positive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}{formatPercent(coin.price_change_percentage_24h)}</div></div><div className="chart-wrap"><Sparkline coin={coin} /></div></div>
      <div className="market-card-foot"><span>Market cap <strong>{formatCurrency(coin.market_cap, true)}</strong></span><span>Vol <strong>{formatCurrency(coin.total_volume, true)}</strong></span></div>
    </article>
  );
}

function TableRow({ coin, index, watchlisted, onToggle }: { coin: Coin; index: number; watchlisted: boolean; onToggle: () => void }) {
  const positive = coin.price_change_percentage_24h >= 0;
  return <div className="table-row"><div className="rank-cell">{String(index + 1).padStart(2, "0")}</div><div className="table-coin"><CoinAvatar coin={coin} index={index} /><div><strong>{coin.name}</strong><span>{coin.symbol.toUpperCase()}</span></div></div><div className="table-price">{formatCurrency(coin.current_price)}</div><div className={`table-change ${positive ? "is-positive" : "is-negative"}`}>{positive ? "+" : ""}{coin.price_change_percentage_24h.toFixed(2)}%</div><div className="table-chart"><Sparkline coin={coin} muted /></div><div className="table-cap">{formatCurrency(coin.market_cap, true)}</div><button className={`table-star ${watchlisted ? "table-star--active" : ""}`} onClick={onToggle} aria-label="Toggle watchlist"><Star size={15} fill={watchlisted ? "currentColor" : "none"} /></button></div>;
}

function LoadingState() {
  return <div className="loading-state"><Loader2 size={23} className="spin" /><div><strong>Syncing the market</strong><span>Pulling the latest prices from CoinGecko...</span></div></div>;
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <div className="error-state"><div className="error-mark">!</div><div><strong>Market pulse interrupted</strong><span>CoinGecko is taking a breather. We kept a sample feed on-screen so you can explore the interface.</span></div><button onClick={onRetry}><RefreshCw size={14} /> Try again</button></div>;
}

function EmptyWatchlist({ onDiscover }: { onDiscover: () => void }) {
  return <div className="empty-state"><div className="empty-orbit"><Star size={24} /></div><h3>Your signal board is clear.</h3><p>Star a coin from Market Overview and it will land here for quick access.</p><button onClick={onDiscover}>Explore markets <ChevronRight size={15} /></button></div>;
}

function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activePanel, setActivePanel] = useState<Panel>("overview");
  const [coins, setCoins] = useState<Coin[]>([]);
  const [watchlist, setWatchlist] = useState<string[]>(["bitcoin", "solana"]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const splashTimer = window.setTimeout(() => setShowSplash(false), 3000);
    return () => window.clearTimeout(splashTimer);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setApiError(false);
    fetch(API_URL, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Market request failed");
        return response.json();
      })
      .then((payload: Coin[]) => { setCoins(payload); setLoading(false); })
      .catch((error: Error) => {
        if (error.name !== "AbortError") { setCoins(fallbackCoins); setApiError(true); setLoading(false); }
      });
    return () => controller.abort();
  }, [retryKey]);

  const displayCoins = coins.length ? coins : fallbackCoins;
  const filteredCoins = displayCoins.filter((coin) => `${coin.name} ${coin.symbol}`.toLowerCase().includes(search.toLowerCase()));
  const trendingCoins = [...displayCoins].sort((a, b) => b.price_change_percentage_24h - a.price_change_percentage_24h).slice(0, 6);
  const watchlistedCoins = displayCoins.filter((coin) => watchlist.includes(coin.id));
  const totalMarketCap = displayCoins.reduce((sum, coin) => sum + (coin.market_cap || 0), 0);
  const toggleWatchlist = (coinId: string) => setWatchlist((current) => current.includes(coinId) ? current.filter((id) => id !== coinId) : [...current, coinId]);
  const meta = panelMeta[activePanel];

  if (showSplash) return <div className="splash-screen"><div className="splash-glow" /><div className="splash-content"><div className="splash-logo"><LogoMark /><span>CoinDash</span></div><div className="splash-tagline">Your market. In motion.</div><div className="splash-loader"><span /><span /><span /></div></div><div className="splash-foot"><span>CD / 001</span><span>LIVE MARKET INTELLIGENCE</span></div></div>;

  return <div className="app-shell">
    <Sidebar activePanel={activePanel} onChange={setActivePanel} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
    <main className="main-content">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={20} /></button><div className="breadcrumb"><span>Workspace</span><ChevronRight size={14} /><strong>{meta.label}</strong></div><div className="topbar-actions"><div className="live-indicator"><span /> Data stream live</div><button className="icon-button" aria-label="Notifications"><Bell size={18} /><i /></button><div className="topbar-divider" /><div className="top-avatar">JD</div></div></header>
      <div className="content-wrap">
        <section className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> {meta.eyebrow}</div><h1>{meta.title}</h1><p>{meta.description}</p></div><div className="heading-meta"><div className="updated-label"><Clock3 size={14} /> Updated just now</div><button className="refresh-button" onClick={() => setRetryKey((key) => key + 1)}><RefreshCw size={15} /> Refresh</button></div></section>
        {activePanel === "overview" && <>
          <section className="stats-grid"><StatCard label="Global market cap" value={`$${formatCurrency(totalMarketCap || 3200000000, true).replace("$", "")}`} change="+2.41%" icon={<CircleDollarSign size={18} />} /><StatCard label="24h trading volume" value="$128.4B" change="+8.12%" tone="purple" icon={<BarChart3 size={18} />} /><StatCard label="BTC dominance" value="54.8%" change="+0.36%" tone="white" icon={<LineChart size={18} />} /><StatCard label="Fear & greed" value="72 / Greed" tone="lime" icon={<Zap size={18} />} /></section>
          <section className="section-block"><div className="section-header"><div><h2>Market pulse</h2><span className="section-caption">Top assets by market capitalization</span></div><div className="section-actions"><div className="search-box"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search assets..." aria-label="Search assets" />{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={14} /></button>}<kbd>/</kbd></div><button className="view-toggle active"><LayoutDashboard size={15} /></button><button className="view-toggle"><LineChart size={15} /></button></div></div>
            {apiError && <ErrorState onRetry={() => setRetryKey((key) => key + 1)} />}
            {loading ? <LoadingState /> : filteredCoins.length ? <><div className="market-grid">{filteredCoins.slice(0, 6).map((coin, index) => <MarketCard key={coin.id} coin={coin} index={index} watchlisted={watchlist.includes(coin.id)} onToggle={() => toggleWatchlist(coin.id)} />)}</div><div className="market-table-wrap"><div className="table-head"><span>Rank / asset</span><span>Price</span><span>24h change</span><span>7d trend</span><span>Market cap</span><span /></div>{filteredCoins.slice(6, 16).map((coin, index) => <TableRow key={coin.id} coin={coin} index={index + 6} watchlisted={watchlist.includes(coin.id)} onToggle={() => toggleWatchlist(coin.id)} />)}</div></> : <div className="no-results"><Search size={20} /><span>No assets match “{search}”</span></div>}
          </section>
        </>}
        {activePanel === "trending" && <section className="section-block trending-panel"><div className="trend-intro"><div className="trend-orb"><Flame size={28} /></div><div><h2>Momentum radar</h2><p>Sorted by 24-hour change. This is where the market’s energy is showing up first.</p></div><div className="trend-scan"><span className="scan-dot" /> Scanning 40 assets</div></div>{loading ? <LoadingState /> : <div className="trending-list">{trendingCoins.map((coin, index) => <div className="trend-row hover-lift" key={coin.id}><div className="trend-rank">0{index + 1}</div><CoinAvatar coin={coin} index={index} /><div className="trend-name"><strong>{coin.name}</strong><span>{coin.symbol.toUpperCase()} / USD</span></div><div className="trend-chart"><Sparkline coin={coin} /></div><div className="trend-price"><strong>{formatCurrency(coin.current_price)}</strong><span>Vol {formatCurrency(coin.total_volume, true)}</span></div><div className={`trend-change ${coin.price_change_percentage_24h >= 0 ? "is-positive" : "is-negative"}`}>{coin.price_change_percentage_24h >= 0 ? <ArrowUpRight size={15} /> : <ArrowDownRight size={15} />}{formatPercent(coin.price_change_percentage_24h)}</div><button className={`watch-button ${watchlist.includes(coin.id) ? "watch-button--active" : ""}`} onClick={() => toggleWatchlist(coin.id)}><Star size={16} fill={watchlist.includes(coin.id) ? "currentColor" : "none"} /></button></div>)}</div>}</section>}
        {activePanel === "watchlist" && <section className="section-block watchlist-panel"><div className="watchlist-summary"><div className="watchlist-count"><span className="summary-number">{watchlistedCoins.length}</span><div><strong>Assets on your board</strong><span>Tap the star anywhere to curate your signal.</span></div></div><button className="copy-button" onClick={() => navigator.clipboard?.writeText(watchlistedCoins.map((coin) => coin.symbol.toUpperCase()).join(", "))}><Copy size={14} /> Copy tickers</button></div>{watchlistedCoins.length ? <div className="watchlist-grid">{watchlistedCoins.map((coin, index) => <MarketCard key={coin.id} coin={coin} index={index} watchlisted onToggle={() => toggleWatchlist(coin.id)} />)}</div> : <EmptyWatchlist onDiscover={() => setActivePanel("overview")} />}</section>}
        <footer className="app-footer"><span>CoinDash <b>•</b> made for curious minds</span><span>Data via <a href="https://www.coingecko.com/en/api" target="_blank" rel="noreferrer">CoinGecko API</a> <b>•</b> market data may be delayed</span></footer>
      </div>
    </main>
  </div>;
}

export default App;
